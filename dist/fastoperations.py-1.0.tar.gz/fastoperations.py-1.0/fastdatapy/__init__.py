
__all__=["fastoperations"] # 列表可以根据要导入的模块数而进行新增，列表元素是之前新建的py文件的名字

__version__ = "1.0"


