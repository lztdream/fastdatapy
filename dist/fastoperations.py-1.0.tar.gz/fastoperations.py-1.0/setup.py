from distutils.core import  setup
setup(
      name = 'fastoperations.py',
      version = '1.0',
      author = 'Zhang XuYin, Liu ZhangTao',
      py_modules=['fastdatapy.fastoperations'] #记得改名字
)

